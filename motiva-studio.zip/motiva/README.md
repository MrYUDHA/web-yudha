# Motiva Studio

Situs studio kreatif dengan carousel 3D, teks raksasa beranimasi, efek glitch, menu layar penuh, dan form kontak yang tersimpan lewat backend Node. Semuanya ada di satu file: `server.js`.

## Menjalankan

```bash
node server.js
```

Buka http://localhost:3000. Port bisa diganti: `PORT=8080 node server.js`.

Tidak ada dependensi, cukup Node.js 16 atau lebih baru.

## Isi

- Halaman web (HTML, CSS, JS) tertanam di `server.js`.
- `POST /api/contact` menyimpan pesan ke `messages.json` (dibuat otomatis).
- Pembatas laju: 5 pesan per menit per IP. Input dibersihkan dari tanda `<` dan `>`.

## Mengubah isi

Cari konstanta `PAGE` di `server.js`. Nama brand, teks, warna (variabel `:root`), dan daftar proyek carousel (array `projects`) ada di sana.

## Deploy

Jalankan `node server.js` di VPS atau layanan yang mendukung Node (Railway, Render, Fly.io). Pastikan folder bisa ditulis agar `messages.json` tersimpan.
