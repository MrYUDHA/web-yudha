// MOTIVA — satu file fullstack (server Node + halaman web)
// Jalankan: node server.js  ->  http://localhost:3000
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const DB = path.join(__dirname, 'messages.json');
const rate = new Map();

const read = () => { try { return JSON.parse(fs.readFileSync(DB, 'utf8')); } catch { return []; } };
const esc = s => String(s).replace(/[<>]/g, '').trim().slice(0, 2000);

const PAGE = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MOTIVA — Studio Desain & Gerak</title>
<meta name="description" content="Motiva adalah studio kreatif yang merancang pengalaman web yang diingat orang.">
<style>
:root{
  --bg:#c9c9cb; --ink:#141414; --paper:#ececee; --accent:#ff4d2e; --line:rgba(20,20,20,.18);
  --font: "Helvetica Neue", Helvetica, Arial, "Segoe UI", sans-serif;
  --mono: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
}
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--ink);font-family:var(--font);overflow-x:hidden;-webkit-font-smoothing:antialiased}
body.lock{overflow:hidden}
a{color:inherit;text-decoration:none}
button{font:inherit;color:inherit;background:none;border:0;cursor:pointer}
::selection{background:var(--ink);color:var(--bg)}

/* ---------- preloader ---------- */
.pre{position:fixed;inset:0;background:var(--ink);color:var(--bg);z-index:100;display:flex;align-items:flex-end;justify-content:space-between;padding:4vw;transition:transform 1s cubic-bezier(.76,0,.24,1)}
.pre.done{transform:translateY(-100%)}
.pre .count{font-size:clamp(80px,22vw,300px);font-weight:700;letter-spacing:-.06em;line-height:.8}
.pre .lbl{font-family:var(--mono);font-size:12px;text-transform:uppercase;letter-spacing:.1em;max-width:200px}

/* ---------- cursor ---------- */
.cur{position:fixed;left:0;top:0;width:14px;height:14px;border-radius:50%;background:var(--ink);pointer-events:none;z-index:90;mix-blend-mode:difference;background:#fff;transform:translate(-50%,-50%);transition:width .25s,height .25s}
.cur.big{width:70px;height:70px}
@media (hover:none){.cur{display:none}}

/* ---------- header ---------- */
header{position:fixed;top:0;left:0;right:0;z-index:50;display:flex;justify-content:space-between;align-items:center;padding:22px 32px}
.logo{font-weight:800;letter-spacing:-.04em;font-size:20px;display:flex;align-items:center;gap:8px}
.logo svg{width:22px;height:22px}
.nav{display:flex;gap:10px;align-items:center}
.pill{height:34px;padding:0 18px;border-radius:999px;font-family:var(--mono);font-size:11px;text-transform:uppercase;letter-spacing:.06em;display:inline-flex;align-items:center;gap:8px;border:1px solid var(--ink);transition:.3s}
.pill.dark{background:var(--ink);color:var(--bg)}
.pill:hover{background:var(--accent);border-color:var(--accent);color:#fff}
.dot{width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,.08);display:grid;place-items:center;margin-right:6px}
.dot i{width:6px;height:6px;border-radius:50%;background:var(--accent);animation:pulse 1.6s infinite}
@keyframes pulse{50%{transform:scale(1.8);opacity:.4}}
@media(max-width:600px){header{padding:16px}.dot{display:none}}

/* ---------- menu overlay ---------- */
.menu{position:fixed;inset:0;background:var(--ink);color:var(--paper);z-index:60;clip-path:inset(0 0 100% 0);transition:clip-path .9s cubic-bezier(.76,0,.24,1);display:flex;flex-direction:column;justify-content:center;padding:0 6vw}
.menu.open{clip-path:inset(0 0 0 0)}
.menu a.big{font-size:clamp(48px,11vw,150px);font-weight:700;letter-spacing:-.05em;line-height:.95;display:block;overflow:hidden;transform:translateY(40px);opacity:0;transition:.7s cubic-bezier(.2,.7,.2,1),color .3s}
.menu.open a.big{transform:none;opacity:1}
.menu.open a.big:nth-of-type(2){transition-delay:.08s}.menu.open a.big:nth-of-type(3){transition-delay:.16s}.menu.open a.big:nth-of-type(4){transition-delay:.24s}.menu.open a.big:nth-of-type(5){transition-delay:.32s}
.menu a.big:hover{color:var(--accent);padding-left:2vw}
.menu .close{position:absolute;top:22px;right:32px;color:var(--paper);border-color:var(--paper)}
.menu small{position:absolute;bottom:30px;left:6vw;font-family:var(--mono);font-size:12px;opacity:.6}

/* ---------- hero ---------- */
.hero{position:relative;height:100vh;min-height:620px;overflow:hidden;display:flex;align-items:center;justify-content:center}
.bigtxt{position:absolute;font-weight:800;letter-spacing:-.06em;line-height:.8;font-size:clamp(90px,19vw,330px);white-space:nowrap;user-select:none;z-index:1}
.bigtxt.t1{right:4vw;top:17vh}
.bigtxt.t2{left:6vw;bottom:12vh}
.bigtxt .ch{display:inline-block;transform:translateY(110%);opacity:0;transition:transform 1.1s cubic-bezier(.2,.8,.2,1),opacity 1s}
.loaded .bigtxt .ch{transform:none;opacity:1}
.bigtxt .wrap{overflow:hidden;display:inline-block;padding-bottom:.08em}
.stage{position:relative;z-index:2;width:100%;height:70vh;perspective:1500px;cursor:grab;touch-action:pan-y}
.stage:active{cursor:grabbing}
.tilt{position:absolute;inset:0;transform:rotateZ(-5deg) rotateX(-6deg) scale(1.02);transform-style:preserve-3d}
.ring{position:absolute;left:0;top:50%;width:100%;height:0;transform-style:preserve-3d}
.card{--w:min(38vw,460px);position:absolute;left:50%;top:0;width:var(--w);margin-left:calc(var(--w)/-2);aspect-ratio:16/10;transform:translateY(-50%) rotateY(var(--a)) translateZ(var(--r));backface-visibility:hidden;border-radius:6px;overflow:hidden;background:var(--bg-c);box-shadow:0 30px 60px -20px rgba(0,0,0,.35);will-change:transform}
@media(max-width:700px){.card{--w:68vw}.stage{height:56vh}}
.card .in{position:absolute;inset:0;padding:5%;display:flex;flex-direction:column;justify-content:space-between;color:var(--fg,#fff)}
.card .top{display:flex;justify-content:space-between;font-family:var(--mono);font-size:9px;text-transform:uppercase;letter-spacing:.08em;opacity:.85}
.card h3{font-size:clamp(26px,4.6vw,58px);font-weight:800;letter-spacing:-.05em;line-height:.9}
.card h3 sup{font-size:.35em;font-weight:500}
.card .bot{display:flex;justify-content:space-between;align-items:flex-end;font-family:var(--mono);font-size:9px;text-transform:uppercase;max-width:100%}
.card .shape{position:absolute;right:-8%;bottom:-18%;width:55%;aspect-ratio:1;border-radius:50%;background:var(--sh);opacity:.9;mix-blend-mode:screen;animation:float 6s ease-in-out infinite}
.card .shape.sq{border-radius:12%;transform:rotate(18deg)}
@keyframes float{50%{transform:translateY(-6%) scale(1.06)}}
/* glitch */
.card::before,.card::after{content:"";position:absolute;inset:0;background:var(--bg-c);opacity:0;pointer-events:none;z-index:3}
.card.gl::before{opacity:1;animation:g1 .4s steps(2) infinite;mix-blend-mode:difference}
.card.gl::after{opacity:1;animation:g2 .5s steps(2) infinite;background:var(--accent);mix-blend-mode:multiply}
@keyframes g1{0%{clip-path:inset(10% 0 70% 0);transform:translateX(-8px)}25%{clip-path:inset(60% 0 10% 0);transform:translateX(10px)}50%{clip-path:inset(30% 0 40% 0);transform:translateX(-5px)}75%{clip-path:inset(80% 0 4% 0);transform:translateX(7px)}100%{clip-path:inset(2% 0 88% 0);transform:translateX(-12px)}}
@keyframes g2{0%{clip-path:inset(50% 0 30% 0);transform:translateX(12px)}33%{clip-path:inset(5% 0 80% 0);transform:translateX(-9px)}66%{clip-path:inset(72% 0 8% 0);transform:translateX(6px)}100%{clip-path:inset(25% 0 55% 0);transform:translateX(-4px)}}

.hero .cap{position:absolute;left:32px;bottom:28px;z-index:5;font-family:var(--mono);font-size:10px;line-height:1.5;max-width:210px;text-transform:none;opacity:.75}
.hero .view{position:absolute;right:32px;bottom:28px;z-index:5;font-family:var(--mono);font-size:10px;text-transform:uppercase;border-bottom:1px solid var(--ink);padding-bottom:2px}
.hero .hint{position:absolute;left:50%;bottom:26px;transform:translateX(-50%);z-index:5;font-family:var(--mono);font-size:10px;text-transform:uppercase;letter-spacing:.1em;opacity:.6}
@media(max-width:600px){.hero .cap{left:16px;max-width:150px}.hero .view{right:16px}.hero .hint{display:none}}

/* ---------- generic ---------- */
section{position:relative}
.sec{padding:14vh 5vw}
.eyebrow{font-family:var(--mono);font-size:11px;text-transform:uppercase;letter-spacing:.1em;opacity:.7;margin-bottom:28px;display:flex;gap:10px;align-items:center}
.eyebrow::before{content:"";width:8px;height:8px;background:var(--accent);border-radius:50%}
.rv{opacity:0;transform:translateY(50px);transition:opacity 1s,transform 1s cubic-bezier(.2,.8,.2,1)}
.rv.in{opacity:1;transform:none}

/* marquee */
.marq{background:var(--ink);color:var(--bg);overflow:hidden;padding:26px 0;white-space:nowrap;transform:rotate(-1.2deg);margin:-20px -2vw 0}
.marq .tr{display:inline-block;animation:mq 28s linear infinite;font-size:clamp(34px,6vw,84px);font-weight:700;letter-spacing:-.04em}
.marq span{margin:0 28px}
.marq em{font-style:normal;color:var(--accent)}
@keyframes mq{to{transform:translateX(-50%)}}

/* about */
.about p.lead{font-size:clamp(28px,4.4vw,64px);line-height:1.05;letter-spacing:-.04em;font-weight:600;max-width:1200px}
.about p.lead span{opacity:.25;transition:opacity .4s}
.about p.lead span.on{opacity:1}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;margin-top:12vh;border-top:1px solid var(--line)}
.stat{padding:30px 0;border-bottom:1px solid var(--line)}
.stat b{display:block;font-size:clamp(48px,7vw,110px);letter-spacing:-.06em;font-weight:700;line-height:1}
.stat span{font-family:var(--mono);font-size:11px;text-transform:uppercase;opacity:.65}

/* works */
.works .list{border-top:1px solid var(--ink)}
.row{display:grid;grid-template-columns:70px 1fr auto auto;gap:20px;align-items:center;padding:34px 0;border-bottom:1px solid var(--ink);position:relative;transition:padding .45s cubic-bezier(.2,.8,.2,1),background .3s,color .3s}
.row:hover{padding-left:24px;padding-right:24px;background:var(--ink);color:var(--bg)}
.row .n{font-family:var(--mono);font-size:12px}
.row h4{font-size:clamp(28px,5.5vw,84px);font-weight:700;letter-spacing:-.05em;line-height:1}
.row .tag{font-family:var(--mono);font-size:11px;text-transform:uppercase;opacity:.7}
.row .ar{font-size:28px;transition:transform .4s}
.row:hover .ar{transform:rotate(-45deg)}
@media(max-width:700px){.row{grid-template-columns:36px 1fr auto}.row .tag{display:none}}
.peek{position:fixed;left:0;top:0;width:260px;aspect-ratio:4/3;border-radius:6px;pointer-events:none;z-index:40;opacity:0;transform:translate(-50%,-50%) scale(.6) rotate(-6deg);transition:opacity .25s,transform .25s;overflow:hidden;display:grid;place-items:center;color:#fff;font-weight:800;font-size:38px;letter-spacing:-.05em}
.peek.on{opacity:1;transform:translate(-50%,-50%) scale(1) rotate(-3deg)}
@media(hover:none){.peek{display:none}}

/* services */
.svc{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px}
.sv{background:var(--paper);border-radius:10px;padding:30px;min-height:340px;display:flex;flex-direction:column;justify-content:space-between;position:relative;overflow:hidden;transition:transform .5s cubic-bezier(.2,.8,.2,1)}
.sv:hover{transform:translateY(-10px) rotate(-.8deg)}
.sv::after{content:"";position:absolute;width:220px;height:220px;border-radius:50%;right:-80px;bottom:-80px;background:var(--c);transition:transform .6s cubic-bezier(.2,.8,.2,1);opacity:.9}
.sv:hover::after{transform:scale(2.4)}
.sv .num{font-family:var(--mono);font-size:12px;position:relative;z-index:1}
.sv h5{font-size:34px;letter-spacing:-.04em;line-height:1;position:relative;z-index:1}
.sv p{font-size:14px;line-height:1.5;opacity:.75;margin-top:12px;position:relative;z-index:1;max-width:260px}

/* process */
.proc{background:var(--ink);color:var(--paper);border-radius:28px;margin:0 2vw}
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:40px;margin-top:6vh;counter-reset:s}
.step{border-top:1px solid rgba(255,255,255,.25);padding-top:20px;counter-increment:s}
.step::before{content:"0" counter(s);font-family:var(--mono);color:var(--accent);font-size:13px}
.step h6{font-size:30px;letter-spacing:-.03em;margin:14px 0 8px}
.step p{font-size:14px;line-height:1.55;opacity:.65}
.proc h2,.contact h2{font-size:clamp(44px,8vw,130px);letter-spacing:-.06em;line-height:.9}

/* contact */
.contact{padding-bottom:6vh}
.contact h2{margin-bottom:6vh}
.contact h2 em{font-style:normal;color:var(--accent)}
form{display:grid;grid-template-columns:1fr 1fr;gap:26px;max-width:1100px}
.f{display:flex;flex-direction:column;gap:8px;grid-column:span 1}
.f.full{grid-column:1/-1}
.f label{font-family:var(--mono);font-size:11px;text-transform:uppercase;opacity:.7}
.f input,.f textarea,.f select{background:none;border:0;border-bottom:1px solid var(--ink);padding:12px 0;font:inherit;font-size:20px;outline:0;color:inherit;transition:border-color .3s}
.f input:focus,.f textarea:focus,.f select:focus{border-color:var(--accent)}
.f textarea{resize:vertical;min-height:90px}
.send{grid-column:1/-1;justify-self:start;height:70px;padding:0 44px;border-radius:999px;background:var(--ink);color:var(--bg);font-size:18px;position:relative;overflow:hidden;transition:.3s}
.send:hover{background:var(--accent)}
.send[disabled]{opacity:.5}
@media(max-width:700px){form{grid-template-columns:1fr}.f{grid-column:1/-1}}
footer{display:flex;flex-wrap:wrap;gap:20px;justify-content:space-between;padding:6vh 5vw 4vh;font-family:var(--mono);font-size:11px;text-transform:uppercase}
footer .links{display:flex;gap:22px}
footer a:hover{color:var(--accent)}
.toast{position:fixed;left:50%;bottom:30px;transform:translate(-50%,120px);background:var(--ink);color:var(--bg);padding:16px 26px;border-radius:999px;z-index:95;font-size:14px;transition:transform .5s cubic-bezier(.2,.8,.2,1)}
.toast.show{transform:translate(-50%,0)}
.progress{position:fixed;left:0;top:0;height:3px;background:var(--accent);z-index:99;width:0}
</style>
</head>
<body>

<div class="progress" id="progress"></div>
<div class="cur" id="cur"></div>

<div class="pre" id="pre">
  <div class="lbl">Motiva Studio — memuat pengalaman</div>
  <div class="count"><span id="pct">0</span>%</div>
</div>

<header>
  <a href="#top" class="logo" data-h>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M3 20 12 4l9 16M7.5 14h9"/></svg>MOTIVA<sup style="font-size:9px">®</sup>
  </a>
  <div class="nav">
    <span class="dot"><i></i></span>
    <a href="#contact" class="pill dark" data-h>Let's talk</a>
    <button class="pill" id="menuBtn" data-h>Menu <span>—</span></button>
  </div>
</header>

<nav class="menu" id="menu">
  <button class="pill close" id="menuClose">Tutup ✕</button>
  <a class="big" href="#top" data-m>Beranda</a>
  <a class="big" href="#about" data-m>Tentang</a>
  <a class="big" href="#works" data-m>Karya</a>
  <a class="big" href="#services" data-m>Layanan</a>
  <a class="big" href="#contact" data-m>Kontak</a>
  <small>hello@motiva.studio — Makassar, ID</small>
</nav>

<main id="top">
<!-- HERO -->
<section class="hero" id="hero">
  <div class="bigtxt t1" data-split>DESIGN IN</div>
  <div class="bigtxt t2" data-split>MOTION</div>

  <div class="stage" id="stage">
    <div class="tilt"><div class="ring" id="ring"></div></div>
  </div>

  <p class="cap">Konsep, eksplorasi, dan eksperimen antarmuka yang kami bagikan secara terbuka sebagai bagian dari proses kreatif.</p>
  <div class="hint">← geser / scroll →</div>
  <a href="#works" class="view" data-h>Lihat karya →</a>
</section>

<div class="marq"><div class="tr" id="mq"></div></div>

<!-- ABOUT -->
<section class="sec about" id="about">
  <div class="eyebrow rv">Tentang kami</div>
  <p class="lead" id="lead">Kami merancang situs web yang tidak membosankan. Setiap gerakan punya tujuan, setiap piksel punya karakter, dan setiap pengunjung pulang dengan sesuatu untuk diingat.</p>
  <div class="stats">
    <div class="stat rv"><b data-n="120">0</b><span>Proyek rilis</span></div>
    <div class="stat rv"><b data-n="38">0</b><span>Penghargaan desain</span></div>
    <div class="stat rv"><b data-n="14">0</b><span>Negara klien</span></div>
    <div class="stat rv"><b data-n="9">0</b><span>Tahun berkarya</span></div>
  </div>
</section>

<!-- WORKS -->
<section class="sec works" id="works">
  <div class="eyebrow rv">Karya pilihan</div>
  <div class="list" id="list"></div>
</section>

<!-- SERVICES -->
<section class="sec" id="services">
  <div class="eyebrow rv">Layanan</div>
  <div class="svc">
    <div class="sv rv" style="--c:#ff4d2e"><span class="num">01</span><div><h5>Desain Web</h5><p>Situs yang unik, cepat, dan terasa hidup di setiap layar.</p></div></div>
    <div class="sv rv" style="--c:#7b61ff"><span class="num">02</span><div><h5>Motion & 3D</h5><p>Animasi interaktif, transisi halaman, dan pengalaman imersif.</p></div></div>
    <div class="sv rv" style="--c:#14b886"><span class="num">03</span><div><h5>Branding</h5><p>Identitas visual yang konsisten dari logo sampai antarmuka.</p></div></div>
    <div class="sv rv" style="--c:#ffb300"><span class="num">04</span><div><h5>Pengembangan</h5><p>Frontend dan backend yang rapi, aman, dan mudah dirawat.</p></div></div>
  </div>
</section>

<!-- PROCESS -->
<section class="sec proc" id="process">
  <div class="eyebrow rv">Cara kerja</div>
  <h2 class="rv">Dari ide<br>sampai rilis.</h2>
  <div class="steps">
    <div class="step rv"><h6>Riset</h6><p>Memahami tujuan, audiens, dan kompetitor sebelum satu garis pun digambar.</p></div>
    <div class="step rv"><h6>Konsep</h6><p>Arah visual, moodboard, dan prototipe gerak untuk disepakati bersama.</p></div>
    <div class="step rv"><h6>Produksi</h6><p>Desain final dan pengkodean dengan performa sebagai prioritas.</p></div>
    <div class="step rv"><h6>Peluncuran</h6><p>Uji lintas perangkat, optimasi, lalu rilis dan pendampingan.</p></div>
  </div>
</section>

<!-- CONTACT -->
<section class="sec contact" id="contact">
  <div class="eyebrow rv">Kontak</div>
  <h2 class="rv">Punya ide?<br><em>Ayo</em> bicara.</h2>
  <form id="form" class="rv" novalidate>
    <div class="f"><label for="name">Nama</label><input id="name" name="name" required autocomplete="name"></div>
    <div class="f"><label for="email">Email</label><input id="email" name="email" type="email" required autocomplete="email"></div>
    <div class="f full"><label for="type">Jenis proyek</label>
      <select id="type" name="type"><option>Desain situs web</option><option>Motion & 3D</option><option>Branding</option><option>Pengembangan aplikasi</option></select></div>
    <div class="f full"><label for="msg">Pesan</label><textarea id="msg" name="message" required></textarea></div>
    <button class="send" id="send" type="submit" data-h>Kirim pesan →</button>
  </form>
</section>
</main>

<footer>
  <span>© 2026 Motiva Studio</span>
  <div class="links"><a href="#" data-h>Instagram</a><a href="#" data-h>Dribbble</a><a href="#" data-h>LinkedIn</a></div>
  <span id="clock"></span>
</footer>

<div class="peek" id="peek"></div>
<div class="toast" id="toast"></div>

<script>
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const lerp = (a, b, t) => a + (b - a) * t;

  /* ---------- data ---------- */
  const projects = [
    { t:'AURORA', sup:'®', sub:'Light is language', tag:'Branding', bg:'linear-gradient(135deg,#3b1d12,#8a4a2b)', sh:'#ffb27a', fg:'#fff' },
    { t:'KINETIC', sup:'', sub:'Move with purpose', tag:'Web', bg:'linear-gradient(135deg,#f4f4f6,#d9d9de)', sh:'#ff4d2e', fg:'#141414' },
    { t:'MONOLITH', sup:'™', sub:'Built to last', tag:'Web 3D', bg:'linear-gradient(135deg,#0f1b2d,#27508a)', sh:'#6ea8ff', fg:'#fff' },
    { t:'PIXELA', sup:'', sub:'Play in pixels', tag:'Motion', bg:'linear-gradient(135deg,#f9a8d4,#e056a0)', sh:'#fff1a8', fg:'#2b0a1d' },
    { t:'LUMEN', sup:'®', sub:'Seen in new light', tag:'Branding', bg:'linear-gradient(135deg,#143d2f,#1aa57a)', sh:'#d7ff7a', fg:'#fff' },
    { t:'ORBIT', sup:'', sub:'Everything revolves', tag:'App', bg:'linear-gradient(135deg,#2a1b5e,#7b61ff)', sh:'#ff9bd6', fg:'#fff' },
    { t:'SOLSTICE', sup:'', sub:'Longest day', tag:'Web', bg:'linear-gradient(135deg,#ffd27a,#ff7a3d)', sh:'#fff', fg:'#2b1200' }
  ];

  /* ---------- preloader ---------- */
  const pre = $('#pre'), pct = $('#pct');
  let p = 0;
  const tick = setInterval(() => {
    p += Math.random() * 9 + 3;
    if (p >= 100) { p = 100; clearInterval(tick); setTimeout(() => { pre.classList.add('done'); document.body.classList.add('loaded'); }, 250); }
    pct.textContent = Math.floor(p);
  }, 60);

  /* ---------- split headline ---------- */
  $$('[data-split]').forEach((el, k) => {
    const txt = el.textContent; el.textContent = ''; el.setAttribute('aria-label', txt);
    [...txt].forEach((c, i) => {
      const w = document.createElement('span'); w.className = 'wrap';
      const s = document.createElement('span'); s.className = 'ch';
      s.textContent = c === ' ' ? '\\u00A0' : c;
      s.style.transitionDelay = (1.1 + k * .35 + i * .05) + 's';
      w.appendChild(s); el.appendChild(w);
    });
  });

  /* ---------- 3D ring ---------- */
  const ring = $('#ring'), stage = $('#stage');
  const n = projects.length, step = 360 / n;
  const cards = projects.map((d, i) => {
    const c = document.createElement('div');
    c.className = 'card';
    c.style.setProperty('--bg-c', d.bg);
    c.style.setProperty('--sh', d.sh);
    c.style.setProperty('--fg', d.fg);
    c.innerHTML = \`<div class="in">
      <div class="top"><span>\${d.tag}</span><span>0\${i + 1}/0\${n}</span></div>
      <h3>\${d.t}<sup>\${d.sup}</sup></h3>
      <div class="bot"><span>\${d.sub}</span><span>2026</span></div>
    </div><div class="shape \${i % 2 ? 'sq' : ''}"></div>\`;
    ring.appendChild(c); return c;
  });
  function layout() {
    const w = cards[0].offsetWidth;
    const r = (w / 2) / Math.tan(Math.PI / n) * 1.12;
    cards.forEach((c, i) => { c.style.setProperty('--a', (i * step) + 'deg'); c.style.setProperty('--r', r + 'px'); });
    ring.dataset.r = r;
  }
  layout(); addEventListener('resize', layout);

  let rot = 0, target = 0, dragging = false, lastX = 0, vel = 0, idle = 0;
  const down = x => { dragging = true; lastX = x; idle = 0; };
  const move = x => { if (!dragging) return; target -= (x - lastX) * .22; lastX = x; };
  const up = () => dragging = false;
  stage.addEventListener('mousedown', e => down(e.clientX));
  addEventListener('mousemove', e => move(e.clientX));
  addEventListener('mouseup', up);
  stage.addEventListener('touchstart', e => down(e.touches[0].clientX), { passive: true });
  stage.addEventListener('touchmove', e => move(e.touches[0].clientX), { passive: true });
  stage.addEventListener('touchend', up);
  stage.addEventListener('wheel', e => { if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) { target += e.deltaX * .12; idle = 0; e.preventDefault(); } }, { passive: false });
  let lastScroll = scrollY;

  /* ---------- frame loop ---------- */
  const cur = $('#cur');
  let mx = innerWidth / 2, my = innerHeight / 2, cx = mx, cy = my;
  addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });
  const bar = $('#progress');

  function frame() {
    idle++;
    if (!dragging && idle > 90) target += .12;
    const prev = rot;
    rot = lerp(rot, target, .07);
    vel = rot - prev;
    const r = +ring.dataset.r || 600;
    ring.style.transform = \`translateZ(\${-r}px) rotateY(\${-rot}deg)\`;

    // snap-ish glitch driven by speed
    const fast = Math.abs(vel) > 1.1;
    cards.forEach(c => c.classList.toggle('gl', fast));

    // scroll velocity warps the ring
    const sv = scrollY - lastScroll; lastScroll = scrollY;
    $('.tilt').style.transform = \`rotateZ(\${-5 + Math.max(-4, Math.min(4, sv * .12))}deg) rotateX(-6deg) scale(1.02)\`;

    cx = lerp(cx, mx, .2); cy = lerp(cy, my, .2);
    cur.style.transform = \`translate(\${cx}px,\${cy}px) translate(-50%,-50%)\`;

    const h = document.documentElement;
    bar.style.width = (scrollY / (h.scrollHeight - innerHeight) * 100) + '%';
    requestAnimationFrame(frame);
  }
  frame();

  // brief glitch burst every few seconds for life
  setInterval(() => {
    if (dragging) return;
    const c = cards[Math.floor(Math.random() * n)];
    c.classList.add('gl'); setTimeout(() => c.classList.remove('gl'), 260);
  }, 3200);

  /* ---------- cursor hover ---------- */
  $$('[data-h],a,button,.row').forEach(el => {
    el.addEventListener('mouseenter', () => cur.classList.add('big'));
    el.addEventListener('mouseleave', () => cur.classList.remove('big'));
  });

  /* ---------- menu ---------- */
  const menu = $('#menu');
  const toggle = v => { menu.classList.toggle('open', v); document.body.classList.toggle('lock', v); };
  $('#menuBtn').onclick = () => toggle(true);
  $('#menuClose').onclick = () => toggle(false);
  $$('[data-m]').forEach(a => a.addEventListener('click', () => toggle(false)));
  addEventListener('keydown', e => e.key === 'Escape' && toggle(false));

  /* ---------- marquee ---------- */
  const words = ['Desain', 'Gerak', '3D', 'Branding', 'Web', 'Interaksi'];
  const seq = words.map(w => \`<span>\${w}</span><em>✦</em>\`).join('');
  $('#mq').innerHTML = seq + seq + seq + seq;

  /* ---------- scroll reveal ---------- */
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .15 });
  $$('.rv').forEach(el => io.observe(el));

  /* ---------- counters ---------- */
  const co = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return; co.unobserve(e.target);
    const to = +e.target.dataset.n, t0 = performance.now();
    (function up(t) { const k = Math.min(1, (t - t0) / 1600); e.target.textContent = Math.floor(to * (1 - Math.pow(1 - k, 4))) + (k === 1 ? '+' : ''); if (k < 1) requestAnimationFrame(up); })(t0);
  }), { threshold: .6 });
  $$('[data-n]').forEach(el => co.observe(el));

  /* ---------- word-by-word lead ---------- */
  const lead = $('#lead');
  lead.innerHTML = lead.textContent.split(' ').map(w => \`<span>\${w}</span>\`).join(' ');
  const ws = $$('span', lead);
  const lw = () => {
    const rc = lead.getBoundingClientRect();
    const k = Math.min(1, Math.max(0, (innerHeight * .85 - rc.top) / (rc.height + innerHeight * .3)));
    ws.forEach((s, i) => s.classList.toggle('on', i / ws.length < k));
  };
  addEventListener('scroll', lw, { passive: true }); lw();

  /* ---------- works list + hover preview ---------- */
  const list = $('#list'), peek = $('#peek');
  projects.forEach((d, i) => {
    const r = document.createElement('div'); r.className = 'row rv';
    r.innerHTML = \`<span class="n">0\${i + 1}</span><h4>\${d.t}</h4><span class="tag">\${d.tag}</span><span class="ar">→</span>\`;
    r.addEventListener('mouseenter', () => { peek.style.background = d.bg; peek.style.color = d.fg; peek.textContent = d.t; peek.classList.add('on'); });
    r.addEventListener('mouseleave', () => peek.classList.remove('on'));
    r.addEventListener('mousemove', e => { peek.style.left = e.clientX + 'px'; peek.style.top = e.clientY + 'px'; });
    r.addEventListener('mouseenter', () => cur.classList.add('big'));
    r.addEventListener('mouseleave', () => cur.classList.remove('big'));
    list.appendChild(r); io.observe(r);
  });

  /* ---------- clock ---------- */
  const clock = $('#clock');
  const tickClock = () => clock.textContent = 'Makassar ' + new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Makassar', hour: '2-digit', minute: '2-digit' }) + ' WITA';
  tickClock(); setInterval(tickClock, 30000);

  /* ---------- toast ---------- */
  const toast = $('#toast');
  const say = m => { toast.textContent = m; toast.classList.add('show'); setTimeout(() => toast.classList.remove('show'), 3600); };

  /* ---------- form → backend ---------- */
  $('#form').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target, btn = $('#send');
    const data = Object.fromEntries(new FormData(f));
    if (!data.name.trim() || !/^\\S+@\\S+\\.\\S+$/.test(data.email) || !data.message.trim()) { say('Lengkapi nama, email valid, dan pesan.'); return; }
    btn.disabled = true; btn.textContent = 'Mengirim…';
    try {
      const res = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error('server');
      say('Terima kasih! Pesanmu sudah terkirim ✓');
    } catch {
      // fallback saat dibuka tanpa server (mis. file langsung)
      const q = JSON.parse(localStorage.getItem('motiva_outbox') || '[]'); q.push({ ...data, at: Date.now() });
      localStorage.setItem('motiva_outbox', JSON.stringify(q));
      say('Server belum aktif, pesan disimpan di perangkat ini.');
    }
    f.reset(); btn.disabled = false; btn.textContent = 'Kirim pesan →';
  });
})();
</script>
</body>
</html>
`;

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/api/contact') {
    const ip = req.socket.remoteAddress;
    const now = Date.now();
    const hits = (rate.get(ip) || []).filter(t => now - t < 60000);
    if (hits.length >= 5) { res.writeHead(429); return res.end('{"ok":false}'); }
    hits.push(now); rate.set(ip, hits);

    let body = '';
    req.on('data', c => { body += c; if (body.length > 1e5) req.destroy(); });
    req.on('end', () => {
      try {
        const d = JSON.parse(body);
        if (!d.name || !/^\S+@\S+\.\S+$/.test(d.email || '') || !d.message) throw new Error('invalid');
        const all = read();
        all.push({ name: esc(d.name), email: esc(d.email), type: esc(d.type || ''), message: esc(d.message), at: new Date().toISOString() });
        fs.writeFileSync(DB, JSON.stringify(all, null, 2));
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end('{"ok":true}');
      } catch {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end('{"ok":false}');
      }
    });
    return;
  }

  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(PAGE);
  }
  res.writeHead(404); res.end('Not found');
});

server.listen(PORT, () => console.log('Motiva berjalan di http://localhost:' + PORT));
